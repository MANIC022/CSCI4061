# project_2_posted
Project #2 outline for students

/* CSCI-4061 Fall 2022
Group Member #1: <Amit Manicka> <manic022>
Group Member #2: <Aditya Prabhu> <prabh079>
Group Member #3: <Anton Priborkin> <pribo002>

Contributions:
Amit wrote get_num_tabs(), get_free_tab(), init_tabs(), non_block_pipe(), handle_uri(), uri_entered_cb(), new_tab_created_cb(), menu_item_selected_cb(), run_control(), and main()

Aditya wrote fav_ok(), update_favorites_file(), init_favorites(), uri_entered_cb(), run_control(), and main()
Anton wrote fav_ok(), update_favorites_file(), init_favorites()

