#ifndef INC_091420_BREAKOUT_MAIN_H
#define INC_091420_BREAKOUT_MAIN_H

#include <stdio.h>
static const int maxLen = 100;

#endif //INC_091420_BREAKOUT_MAIN_H
