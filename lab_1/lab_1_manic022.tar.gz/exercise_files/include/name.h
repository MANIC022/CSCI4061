#ifndef INC_091420_BREAKOUT_NAME_H
#define INC_091420_BREAKOUT_NAME_H

void getName(char * name);

#endif //INC_091420_BREAKOUT_NAME_H
